<!-- Tampilan Berada di Home, Not Here:D -->
<?php 
header("Location: home.php");
exit();
?>